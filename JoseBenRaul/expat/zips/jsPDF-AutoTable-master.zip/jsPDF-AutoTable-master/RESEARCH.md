# Research

## 30 Apr 2020
- Tree shaking html and css parsing away would save 3 kb of 31 kb minified dist file (10%)