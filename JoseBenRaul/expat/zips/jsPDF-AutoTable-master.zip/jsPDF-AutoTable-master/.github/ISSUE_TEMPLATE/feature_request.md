If you have a question of how to use this plugin, please post on StackOverflow with the tags jspdf and jspdf-autotable.

If you have found a bug, try to describe it in a way that makes it possible to reproduce. Code is always helpful, and live code even more so. Here is a [codepen](http://codepen.io/someatoms/pen/EjwPEb) with `jspdf` and `jspdf-autotable` included that you can fork.
